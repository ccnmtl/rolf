Whitelist Group Affil Mapper for djangowind


