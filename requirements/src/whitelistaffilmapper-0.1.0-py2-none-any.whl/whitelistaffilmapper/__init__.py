# flake8: noqa
from .mapper import WhitelistAffilGroupMapper
